const { validationResult } = require('express-validator');
const database = require('../models/database.js');
const Thread = require('../models/Thread.js');

const threadController = {
    getCreateThread: (req, res) => {
        res.render('createThread');
    },

    getThread: (req, res) => {
        var query = req.params;

        database.findOne(Thread, query, null, (threadObj) => {
            if(threadObj instanceof Object) {
                var data = {
                    _id: threadObj._id,
                    dateCreated: threadObj.dateCreated,
                    title: threadObj.title,
                    username: threadObj.username,
                    content: threadObj.content
                }

                res.render('thread', data);
            }
            else {
                req.flash('error_msg', 'Thread does not exist...');
                res.redirect('/');
            }
        });
    },

    getCheckDuplicate: (req, res) => {
        var query = req.query;

        database.findOne(Thread, query, null, (found) => {
            if(found instanceof Object)
                res.send(found);
            else
                res.send('');
        });
    },

    postAddThread: (req, res) => {
        const errors = validationResult(req);

        if(errors.isEmpty()) {
            const { threadTitle, threadContent} = req.body;

            database.findOne(Thread, {title: threadTitle}, null, (threadObj) => {
                if(threadObj instanceof Object) {

                    req.flash('error_msg', 'Thread title already exists. Please try a different thread title.');
                    res.redirect('/createThread');
                }
                else {
                    var thread = {     
                        title: threadTitle,
                        username: req.session.username,
                        content: threadContent
                    };

                    database.insertOne(Thread, thread, (success) => {
                        if(success) {
                            console.log('Successfully created thread');
                            res.redirect('/thread/' + thread.title);
                        }
                        else {
                            req.flash('error_msg', 'Could not create thread. Please try again.');
                            res.redirect('/createThread');
                        }
                    });
                }
            });
        }
        else {
            const messages = errors.array().map((item) => item.msg);

            req.flash('error_msg', messages.join(' '));
            res.redirect('/createThread');
        }
    },
    postAddComment: (req, res) => {
        var comment = {
            content: req.body.commentContent,
            threadID: req.body.threadID,
        }
        database.insertOne(Comment, comment, (success) => {
            if(success) {
                console.log('Comment added.');
                res.redirect(`/thread/${comment.threadID}`);
            }
            else{
                res.redirect('/');
            }
        });     
    },
    deleteThread: (req,res) => {
        database.deleteOne(Thread, {_id: req.params.id}, (found) => {
            if(found)
            {
                database.deleteMany(Comment, {threadID: req.params.id}, (found) => {
                    if(found)
                    {
                        res.redirect('/');
                    }
                });
            }
        });

    },
    deleteComment: (req,res) => {
        var delcomment = {
            commentID: req.body.commentID,
            threadID: req.body.cmtthreadID
        }
        database.deleteOne(Comment, delcomment, (found) => {
            if(found)
            {
                database.findOne(Thread, {_id: delcomment.threadID},null, (found) => {
                    database.findMany(Comment, {threadID: delcomment.threadID}, null, (found2) =>{
                     layout = {layout: 'thread1.hbs', thread: found, comments: found2};
                     res.render('layouts/thread1', layout);
                    });
                });
            }
            else{
                res.redirect('/');
            }
        });

    },
    getEditThread: (req,res) => {
        var thread = {
            _id: req.params.id,
        }
        console.log(thread._id);
        database.findOne(Thread, thread, null, (found)=>{
            layout = {layout: 'editThread.hbs', thread: found};
            res.render('index', layout);
        })
    },
    postEditThread: (req,res) => {
        var thread = {
            title: req.body.threadTitle,
            content: req.body.threadContent,
        }
        console.log(thread);
        database.findOne(Thread, {_id: req.body.threadID}, null, (found1)=>{
            console.log(found1);
            console.log(found1._id);
            database.updateOne(Thread, {_id: found1._id}, thread, (found2)=>{
                console.log(found1._id);
                res.redirect(`/thread/${found1._id}`);
            })
            
        })
    },
    getEditComment: (req,res) => {
        var comment = {
            _id: req.params.commentid,
        }
        console.log(comment._id);
        database.findOne(Comment, comment, null, (found)=>{
            layout = {layout: 'editComment.hbs', comment: found};
            res.render('index', layout);
        })
    },
    postEditComment: (req,res) => {
        var comment = {
            _id: req.body.commentID,
            content: req.body.commentContent,
        }
        console.log(comment);
        database.findOne(Comment, comment, null, (found1)=>{
            database.updateOne(Comment, {_id: req.body.commentID}, comment, (found2)=>{
                res.redirect(`/thread/${req.params.id}`);
            })
            
        })
    },
}

module.exports = threadController;