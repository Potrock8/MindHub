const express = require('express');
const router = express.Router();
const threadController = require('../controllers/threadController.js');
const { isPrivate } = require('../middlewares/checkAuth.js');
const { addThreadValidation } = require('../middlewares/validator.js');

router.get('/createThread', isPrivate, threadController.getCreateThread);
router.get('/findDuplicateTitle', isPrivate, threadController.getCheckDuplicate);
router.post('/addThread', isPrivate, addThreadValidation, threadController.postAddThread);

router.get('/thread/:title', isPrivate, addThreadValidation, threadController.getThread);
router.post('/:id/addComment', isPrivate, addThreadValidation, threadController.postAddComment);
router.delete('/:id',  isPrivate, addThreadValidation, threadController.deleteThread);
router.post('/:id/deleteComment', isPrivate, addThreadValidation, threadController.deleteComment);
router.get('/:id/editThread', isPrivate, addThreadValidation, threadController.getEditThread);
router.post('/:id/editedThread', isPrivate, addThreadValidation, threadController.postEditThread);
router.get('/:id/editComment/:commentid', isPrivate, addThreadValidation, threadController.getEditComment);
router.post('/:id/editedComment', isPrivate, addThreadValidation, threadController.postEditComment);
module.exports = router;